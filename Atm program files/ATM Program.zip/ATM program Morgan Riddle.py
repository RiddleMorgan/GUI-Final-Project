from tkinter import*
from tkinter import ttk
import tkinter.messagebox

class atm:

    def __init__(self, root):
        self.root = root
        self.root.title( "ATM" )
        self.root.geometry("775x760+280+0")
        self.root.configure(background ='gainsboro')

#Borders for the atm#
        MainFrame = Frame(self.root, bd=20, width=760, height=700,relief=RIDGE)
        MainFrame.grid()

        TopFrame1 = Frame(MainFrame, bd=6, width=730, height=500, relief=RIDGE)
        TopFrame1.grid(row=1, column =0, padx=12)
        TopFrame2 = Frame(MainFrame, bd=6, width=730, height=500, relief=RIDGE)
        TopFrame2.grid(row=0, column =0, padx=8)

        TopFrame2L = Frame(TopFrame2, bd=5, width=185, height=300, relief=RIDGE)
        TopFrame2L.grid(row=0, column =0, padx=8)
        
        TopFrame2M = Frame(TopFrame2, bd=5, width=195, height=300, relief=RIDGE)
        TopFrame2M.grid(row=0, column =1, padx=8)
        
        TopFrame2R = Frame(TopFrame2, bd=5, width=185, height=300, relief=RIDGE)
        TopFrame2R.grid(row=0, column =2, padx=8)
#Widget#
    #note: self. represents class(what we learned in our zoom meeting)#
        
        self.txtReceipt = Text(TopFrame2M, height = 16, width=42, bd=12, font=('new roman',10,'bold'))
        self.txtReceipt.grid(row=0, column =0)
                    #Buttons Left Side#
        self.img_arrow_L = PhotoImage(file ="D:/atm images/arrowL.png")
        
        self.btnArrowL1=Button(TopFrame2L, width=155, height=50, state = DISABLED, image=self.img_arrow_L) .grid(row=0, column =0, padx=2, pady =4)

        self.btnArrowL2=Button(TopFrame2L, width=155, height=50, state = DISABLED, image=self.img_arrow_L) .grid(row=1, column =0, padx=2, pady =4)
        
        self.btnArrowL3=Button(TopFrame2L, width=155, height=50, state = DISABLED, image=self.img_arrow_L) .grid(row=2, column =0, padx=2, pady =4)

        self.btnArrowL4=Button(TopFrame2L, width=155, height=50, state = DISABLED, image=self.img_arrow_L) .grid(row=3, column =0, padx=2, pady =4)

        #These are the arrow buttons for the left side of the atm interface, above this comment ^ #

        self.img_arrow_R = PhotoImage(file ="D:/atm images/arrowR.png")

        self.btnArrowR1=Button(TopFrame2R, width=155, height=50, state = DISABLED, image=self.img_arrow_R) .grid(row=0, column =0, padx=2, pady =4)

        self.btnArrowR2=Button(TopFrame2R, width=155, height=50, state = DISABLED, image=self.img_arrow_R) .grid(row=1, column =0, padx=2, pady =4)
        
        self.btnArrowR3=Button(TopFrame2R, width=155, height=50, state = DISABLED, image=self.img_arrow_R) .grid(row=2, column =0, padx=2, pady =4)

        self.btnArrowR4=Button(TopFrame2R, width=155, height=50, state = DISABLED, image=self.img_arrow_R) .grid(row=3, column =0, padx=2, pady =4)

        #These are the arrow buttons for the right of the atm interface, above this comment ^ #


#Number buttons for entering values in the atm#
        self.img1 = PhotoImage(file ="D:/atm images/one.png")
        self.btn1=Button(TopFrame1, width=155, height=75, image=self.img1) .grid(row=2, column =0, padx=2, pady =4)
        #Number 1 Button#

        self.img2 = PhotoImage(file ="D:/atm images/two.png")
        self.btn2=Button(TopFrame1, width=155, height=75, image=self.img2) .grid(row=2, column =1, padx=2, pady =4)
        #Number 2 Button#

        self.img3 = PhotoImage(file ="D:/atm images/three.png")
        self.btn3=Button(TopFrame1, width=155, height=75, image=self.img3) .grid(row=2, column =2, padx=2, pady =4)
        #Number 3 Button#

        self.img4 = PhotoImage(file ="D:/atm images/four.png")
        self.btn4=Button(TopFrame1, width=155, height=75, image=self.img4) .grid(row=3, column =0, padx=2, pady =4)
        #Number 4 Button#

        self.img5 = PhotoImage(file ="D:/atm images/five.png")
        self.btn5=Button(TopFrame1, width=155, height=75, image=self.img5) .grid(row=3, column =1, padx=2, pady =4)
        #Number 5 Button#
        
        self.img6 = PhotoImage(file ="D:/atm images/six.png")
        self.btn6=Button(TopFrame1, width=155, height=75, image=self.img6) .grid(row=3, column =2, padx=2, pady =4)
        #Number 6 Button#
        
        self.img7 = PhotoImage(file ="D:/atm images/seven.png")
        self.btn7=Button(TopFrame1, width=155, height=75, image=self.img7) .grid(row=4, column =0, padx=2, pady =4)
        #Number 7 Button#
        
        self.img8 = PhotoImage(file ="D:/atm images/eight.png")
        self.btn8=Button(TopFrame1, width=155, height=75, image=self.img8) .grid(row=4, column =1, padx=2, pady =4)
        #Number 8 Button#
        
        self.img9 = PhotoImage(file ="D:/atm images/nine.png")
        self.btn9=Button(TopFrame1, width=155, height=75, image=self.img9) .grid(row=4, column =2, padx=2, pady =4)
        #Number 9 Button#

        self.img0 = PhotoImage(file ="D:/atm images/zero.png")
        self.btn0=Button(TopFrame1, width=155, height=75, image=self.img0) .grid(row=5, column =1, padx=2, pady =4)
        #Number 0 Button#




if __name__=='__main__':
    root = Tk()
    application = atm(root)
    root.mainloop()
